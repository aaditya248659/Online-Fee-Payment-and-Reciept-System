export const API_BASE_URL =
  import.meta.env.VITE_API_BASE_URL ||
  "https://online-fee-payment-and-reciept-system-tb57.onrender.com";
